import React from 'react'
import { Link } from 'react-router-dom';

const Producto = ({ data }) => {
    const { title, price, thumbnail, id } = data
    function handleClick() {
        console.log(`Se redigirá a:${id} en el proximo trabajo practico con React-router`)
    }
    return (
        <div className="producto" id={id}>
            <img
                src={thumbnail}
                alt="imagen random"
                className="imagen"
            />
            <div className="descripcion">{title}</div>
            <div className="descripcion">${price}</div>
            <Link to={`/sites/${id}`}>Detalle</Link>
        </div>
    );
}

export default Producto