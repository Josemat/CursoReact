import React from 'react'
import { RequestApiML } from '../services/RequestApiML';
import Producto from './Producto';



const Productos = () => {
    const productos = RequestApiML()
    return (
        <div className='grilla'>
            {productos && productos.map(element => <Producto data={element} key={element.id} />)}
        </div>
    )
}

export default Productos