import React from 'react';
import {BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import ProductoId from './pages/ProductoId';
import Productos from './components/Productos';


function App() {
  
  
  return <>
    <h1>Tienda de productos</h1>
    <Router>
      <Routes>
        <Route path='/' element={<Productos/>}/>
        <Route path='/sites/:id' element={<ProductoId/>}/>
      </Routes>
    </Router>
    
  </>
  
}

export default App;
