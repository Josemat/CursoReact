import './App.css';
import Formulario from './components/Formulario'

function App() {
  return (
    <div className="App">
      <h2>Formulario Módulo 1</h2>
      <Formulario/>
    </div>
  );
}

export default App;
